from sys import argv
from resources.lib.acestreamhandler import run
from xbmcaddon import Addon

if __name__ == "__main__":
    addon = Addon()
    run(argv)
